

API_ID = 10899585            # Your Telegram API_ID , Get It from my.telegram.org
API_HASH = "41b93f8d5b001664e138489fbddb3f09"       # Your Telegram API_HASH , Get It from my.telegram.org
SESSION_STRING="BACmUIEACyxPYzLiUP70ctHBwnkbuOqSgeluKuj7De8X5PlI1HKVyQwL_hWClHAWZBx4ASslyqo0T1oa8mFTovEX7oXq1s8PaN4lyvheFDVDegXe5P2dsuw_YV-mp3Y4TzYtwbuFbUVdj5AStfDC6jH3-n0fRshtVQriI96vqWqXpBfh0Oc6Mx0KJlzHlJhFHoEYWmLwjuxObjMxDpC1CLlbObN8RBnzGmrYLp6eghMQbMo38y5j-j_KuQwwnqsAav1XavuyJt9xfNYVnalDy0FqCJ0ef21F2O2-fAVFcGY292xeJkaOBWr3TNnxoupDmt-VyMiZ506oiRSdqmtpNVsAPdl2vgAAAAAHWAs9AA"    # Your Telegram Account Session String. Run generate string session to generate



SOURCE_1 = -1001751433607 # Source Channel 1 ID 
DESTINATION_1 = -1001776279028 # Forward Channel 1 ID 

SOURCE_2 = -1001751433607 # Source Channel 2 ID 
DESTINATION_2 = -1001834622086 # Forward Channel 2 ID

# like that add multiple source and multiple destination. Edit main.py file according to this file

# Thank  You.... Sig ning, Many thanks for your support. You are welcome
